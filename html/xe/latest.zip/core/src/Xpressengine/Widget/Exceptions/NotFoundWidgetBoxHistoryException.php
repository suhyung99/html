<?php

namespace Xpressengine\Widget\Exceptions;

use Xpressengine\Widget\WidgetException;

class NotFoundWidgetBoxHistoryException extends WidgetException
{
}